﻿using System;
using System.IO;
using System.Text;
using System.Linq;

class Program
{
    private static Random rand_vubir = new Random();
    static string rand_key()
    {
        const string chars = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890!@#$%^&*()_+-=[]{};:<>,.?/|`~ёЁ№*";
        var finish = (from vubir in Enumerable.Repeat(chars, 6) 
                      select vubir[rand_vubir.Next(vubir.Length)]).ToArray();
        string result = new string(finish);
        return result;
    }
    public static void Main()
    {
        while (true)
        {
            Console.WriteLine("Encrypting text from a file - 1\n" +
                              "Decrypting text from a file - 2\n" +
                              "Decrypting a file by the brute force method - 3\n" +
                              "Exit - 4\nChoose: ");
            int A = Convert.ToInt32(Console.ReadLine());
            if (A == 1)
            {
                string read_data = File.ReadAllText("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/test.txt");
                byte[] readdata = Encoding.UTF8.GetBytes(read_data);
                byte[] encdata = new byte[readdata.Length];
                byte[] key = Encoding.UTF8.GetBytes("Password");
                for (int i = 0; i < readdata.Length; i++)
                {
                    encdata[i] = (byte)(readdata[i] ^ key[i]);
                };
                File.WriteAllBytes("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/test_1.dat", encdata);
            }
            else if (A == 2)
            {
                byte[] readdata = File.ReadAllBytes("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/test_1.dat");
                byte[] decdata = new byte[readdata.Length];
                byte[] key = Encoding.UTF8.GetBytes("Password");
                for (int i = 0; i < readdata.Length; i++)
                {
                    decdata[i] = (byte)(readdata[i] ^ key[i]);
                };
                string dec_data = Encoding.UTF8.GetString(decdata);
                File.WriteAllText("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/test_2.txt", dec_data);
            }
            else if (A == 3)
            {
                string[] keys = new string[869107786];
                int j = 1;
                while (true)
                {
                    byte[] key = new byte[6];
                    string keyy = rand_key();
                    for (int h = 0; h < j; h++)
                    {
                        if (String.Equals(keys[h], keyy))
                            break;
                        else
                        {
                            keys[j] = keyy;
                            key = Encoding.UTF8.GetBytes(keyy);
                            Console.WriteLine(j + "    " + keyy);
                            byte[] readdata = File.ReadAllBytes("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/encfile5.dat");
                            byte[] decdata = new byte[readdata.Length];
                            int k = 0;
                            for (int i = 0; i < readdata.Length; i++)
                            {
                                decdata[i] = (byte)(readdata[i] ^ key[k]);
                                if (k == 5)
                                {
                                    k = 0;
                                }
                                k++;
                            };
                            string dec_data = Encoding.UTF8.GetString(decdata);
                            if (dec_data.Contains("Mit21"))
                            {
                                Console.WriteLine(dec_data);
                                Console.WriteLine("If the text is legible and correct, enter 1, if not - any other number\n");
                                int B = Convert.ToInt32(Console.ReadLine());
                                if (B == 1)
                                {
                                    File.WriteAllText("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/decfile5.txt", dec_data);
                                    File.WriteAllBytes("C:/Users/Bogdan/source/repos/OsnInfB_PZ2/key.txt", key);
                                }
                                else
                                {
                                    continue;
                                }
                            }
                            j++;
                            break;
                        }
                    }
                }
            }
            else if (A == 4)
            {
                break;
            }
            else
            {
                continue;
            }
        }
    }
}